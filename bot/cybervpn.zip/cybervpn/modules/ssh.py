from cybervpn import *
import subprocess
import json
import re
import base64
import datetime as DT
import requests
import time

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    async def ssh_member_manager(event):
        inline = [
[Button.inline("Trial SSH", "trial-ssh-member"),
 Button.inline("Create SSH", "create-ssh-member")],
[Button.inline("Renew SSH", "renew-ssh-member")],
[Button.inline("‹ Main Menu ›", "menu")]]
        
        location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**═════════════════════════**
     **🟡SSH SERVICE🔸PREMIUM🟡**
**═════════════════════════**
**» Host:** `{DOMAIN}`
**» ISP:** `{location_info["isp"]}`
**═════════════════════════**
**» akun ssh ws hanya Rp.10.000**
**» Pull dengan backupan kami**
**» TopUp min Rp.10.000**
**═════════════════════════**
"""
        await event.edit(msg, buttons=inline)
		
@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def renew_ssh(event):
	async def renew_ssh_(event):
		cmd = 'bot-member-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 SSH Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
	async with bot.conversation(chat) as user:
		await event.respond(' **👤Username Renew:**')
		user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
		user = (await user).raw_text.replace(" ", "")
		cmd_check = f'cat /etc/shadow | grep "{user}"'
		if subprocess.call(cmd_check, shell=True) != 0:
			await event.respond("**Username tidak ditemukan. Silakan masukkan username yang benar.**", buttons=[
[Button.inline("🔄 Renew Ulang","renew-ssh")],
[Button.inline("❌ Cancel","ssh")]])
			return
	async with bot.conversation(chat) as exp:
		await event.respond(' **Ubah Masaaktif:**')
		exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
		exp = (await exp).raw_text
		if not exp.isdigit():
			await event.respond(" **Masaaktif harus berupa angka.**", buttons=[
[Button.inline("🔄 Renew Ulang","renew-sh")],
[Button.inline("❌ Cancel","ssh")]])
			return  # Keluar dari fungsi jika exp bukan angka
		cmd = f'printf "%s\n" "{user}" "{exp}" | renewssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Successfully**",buttons=[[Button.inline("🔙Back","ssh")]])
		else:
			await event.respond(f"**Successfully Renew** `{user}`",buttons=[[Button.inline("🔙Back","ssh")]])
	
		user_id = str(event.sender_id)
		chat = event.chat_id
		sender = await event.get_sender()
		try:
			level = get_level_from_db(user_id)
			print(f'Retrieved level from database: {level}')

			if 'admin' in level or 'user' in level:
				await renew_ssh_(event)
			else:
				await event.answer(f'Akses Ditolak..!!', alert=True)
		except Exception as e:
			print(f'Error: {e}')

	
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		user_id = str(event.sender_id)
		inline = [
[Button.inline("🤖Auto Name","auto-ssh")],
[Button.inline("☣️Trial","trial-ssh"),
Button.inline(" ➕Create","create-ssh")],
[Button.inline(" ❌Delete","delete-ssh"),
Button.inline(" ✅Check","login-ssh")],
[Button.inline(" 👤User","show-ssh"),
Button.inline(" ♻️Renew","renew-ssh")],
[Button.inline(" 🔒Lock","user-lock"),
Button.inline(" 🔑Unlock","user-unlock")],
[Button.inline(" 📝Detail","d-ssh")],
[Button.inline("🔙Back","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		sh = f'cat /etc/ssh/.ssh.db | grep "###" | wc -l'
		ssh_count = subprocess.check_output(sh, shell=True).decode("ascii").strip()
		username = sender.username
		user_id = sender.id
		msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**⚡️ SSH OVPN MANAGER ⚡️**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**»🔰Service:** `SSH OVPN`
**»🔰Jumlah SSH OVPN :** `{ssh_count}` __akun__
**»🔰Hostname/IP:** `{DOMAIN}`
**»🔰ISP:** `{z["isp"]}`
**»🔰Country:** `{z["country"]}`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**»🆔User ID:** `{user_id}`
**»👤Username:@{username}**
"""
		await event.edit(msg,buttons=inline)


	user_id = str(event.sender_id)
	chat = event.chat_id
	sender = await event.get_sender()
	try:
		level = get_level_from_db(user_id)
		print(f'Retrieved level from database: {level}')

		if 'admin' in level or 'user' in level:
			await ssh_(event)
		else:
			await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
	except Exception as e:
		print(f'Error: {e}')