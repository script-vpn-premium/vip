from cybervpn import *
import subprocess
import time
#CEK VMESS
@bot.on(events.CallbackQuery(data=b'info'))
async def info_vps(event):
	async def info_vps_(event):
		cmd = 'bot-vps-info'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""```{z}```
**🤖@WendiVpn**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		
# Tambahkan ini untuk menghapus pesan setelah proses selesai
		user_id = str(event.sender_id)
		chat = event.chat_id
		sender = await event.get_sender()
		try:
			level = get_level_from_db(user_id)
			print(f'Retrieved level from database: {level}')

			if level == 'admin':
				await info_vps_(event)
			else:
				await event.answer('Akses Ditolak..!!', alert=True)

		except Exception as e:
			print(f'Error: {e}')