from cybervpn import *
from telethon import events, Button
import requests

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)
    sh = 'cat /etc/ssh/.ssh.db | grep "###" | wc -l'
    ssh = subprocess.check_output(sh, shell=True).decode("ascii")
    vm = 'cat /etc/xray/config.json | grep "###" | wc -l'
    vms = subprocess.check_output(vm, shell=True).decode("ascii")
    vl = 'cat /etc/vless/.vless.db | grep "###" | wc -l'
    vls = subprocess.check_output(vl, shell=True).decode("ascii")
    tr = 'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
    trj = subprocess.check_output(tr, shell=True).decode("ascii")
    ss = 'cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l'
    ssk = subprocess.check_output(ss, shell=True).decode("ascii")
    sdss = 'cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed \'s/=//g\' | sed \'s/PRETTY_NAME//g\''
    namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
    ipvps = 'curl -s ipv4.icanhazip.com'
    ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
    citsy = 'cat /etc/xray/city'
    city = subprocess.check_output(citsy, shell=True).decode("ascii")

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
    [Button.inline("🔐 BUAT SSH ", "c-ssh")],
    [Button.inline("🌀 BUAT VMESS", "c-vmess")],
    [Button.inline("🔗 BUAT VLESS", "c-vless")],
    [Button.inline("⚔️ CBUAT TROJAN", "c-trojan")],
    [Button.inline("🛡️ BUAT SADWSOCKET", "c-ss")],
    [Button.inline("💰 BERDONASI", "topup")]
]

                member_msg = f"""
📢 **Selamat Datang di Layanan**
**VPN Gratis! Gunakan layanan ini**
**dengan bijak dan sesuai kebutuhan.**

🙎‍♂️ **User ID**  : `{user_id}`  
👥 **Total Pengguna** : `{get_user_count()}`
🤝 **Riswan Store 2023**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
    [Button.inline("SSH WS", "ssh")],
    [Button.inline("VMESS", "vmess"),
     Button.inline("VLESS", "vless")],
    [Button.inline("TROJAN", "trojan"),
     Button.inline("SHADWO", "shadowsocks")],
    [Button.inline("ADD USER", "registrasi-member"),
     Button.inline("HAPUS USER", "delete-member")],
    [Button.inline("LIST USER MEMBER", "show-user")],
    [Button.inline("ADD SALDO MEMBER", "addsaldo")],
    [Button.inline("PENGATURAN", "setting")],
    [Button.inline("REGIS IP SC VPS", "regist")]
]

                admin_msg = f"""
◇━━━━━━━━━━━━━━━━━━━━━━━◇ 
🔰 OS  : `{namaos.strip().replace('"','')}`
🔰 CITY : `{city.strip()}`
🔰 DOMAIN : `{DOMAIN}`
🔰 IP VPS : `{ipsaya.strip()}`
◇━━━━━━━━━━━━━━━━━━━━━━━◇
🔰 Total Account Created:
🔰 SSH OVPN  : `{ssh.strip()} account`
🔰 XRAY VMESS : `{vms.strip()} account`
🔰 XRAY VLESS  : `{vls.strip()} account`
🔰 XRAY TROJAN  : `{trj.strip()} account`
🔰 XRAY SHDOWS: `{ssk.strip()} account`
◇━━━━━━━━━━━━━━━━━━━━━━━◇
🙎‍♂️ User id  : `{user_id}`
◇━━━━━━━━━━━━━━━━━━━━━━━◇
🙎‍♂️ Total user : `{get_user_count()}`
◇━━━━━━━━━━━━━━━━━━━━━━━◇
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f' `Siilahkan Registrasi Terlebih Dahulu` ',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )