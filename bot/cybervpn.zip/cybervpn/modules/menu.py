from cybervpn import *
from telethon import events, Button
import requests

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)
    sh = 'cat /etc/ssh/.ssh.db | grep "###" | wc -l'
    ssh = subprocess.check_output(sh, shell=True).decode("ascii")
    vm = 'cat /etc/xray/config.json | grep "###" | wc -l'
    vms = subprocess.check_output(vm, shell=True).decode("ascii")
    vl = 'cat /etc/vless/.vless.db | grep "###" | wc -l'
    vls = subprocess.check_output(vl, shell=True).decode("ascii")
    tr = 'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
    trj = subprocess.check_output(tr, shell=True).decode("ascii")
    ss = 'cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l'
    ssk = subprocess.check_output(ss, shell=True).decode("ascii")
    sdss = 'cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed \'s/=//g\' | sed \'s/PRETTY_NAME//g\''
    namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
    ipvps = 'curl -s ipv4.icanhazip.com'
    ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
    citsy = 'cat /etc/xray/city'
    city = subprocess.check_output(citsy, shell=True).decode("ascii")

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
    [Button.inline("𝚂𝚂𝙷", "ssh_user")],
    [Button.inline("𝚅𝚖𝚎𝚜𝚜", "vmess_user"),
     Button.inline("𝚅𝚕𝚎𝚜𝚜", "vless_user")],
    [Button.inline("𝚃𝚛𝚘𝚓𝚊𝚗", "trojan_user"),
     Button.inline("𝚂𝚑𝚊𝚍𝚘𝚠𝚜𝚘𝚌𝚔𝚜", "shadowsocks_user")],
    [Button.inline("𝚃𝚘𝚙𝚄𝚙", "topup")]
]

                member_msg = f"""
━━━━━◇ VPN STORE ◇━━━━━━
💸 Harga VPN:
1 Akun • 2 IP • Rp10.000 / 30 Hari

📌 Untuk durasi lebih dari 30 hari
atau lebih dari 2 IP,
silakan hubungi admin:
➡️ @JesVpnt
━━━━━━━━━━━━━━━━━━━━━━
🙎‍♂️ USER ID  : {user_id}  
💰 SALDOMU   : Rp.{saldo_aji}
━━━━━━━━━━━━━━━━━━━━━━
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
    [Button.inline("𝚂𝚂𝙷", "ssh")],
    [Button.inline("𝚅𝚖𝚎𝚜𝚜", "vmess"),
     Button.inline("𝚅𝚕𝚎𝚜𝚜", "vless")],
    [Button.inline("𝚃𝚛𝚘𝚓𝚊𝚗", "trojan"),
     Button.inline("𝚂𝚑𝚊𝚍𝚘𝚠𝚜𝚘𝚌𝚔𝚜", "shadowsocks")],
    [Button.inline("𝙰𝚍𝚍 𝙼𝚎𝚖𝚋𝚎𝚛", "registrasi-member"),
     Button.inline("𝙷𝚊𝚙𝚞𝚜 𝙼𝚎𝚖𝚋𝚎𝚛", "delete-member")],
    [Button.inline("𝙳𝚊𝚏𝚝𝚊𝚛 𝙼𝚎𝚖𝚋𝚎𝚛", "show-user")],
    [Button.inline("𝙰𝚍𝚍 𝚂𝚊𝚕𝚍𝚘 𝚄𝚜𝚎𝚛", "addsaldo")],
    [Button.inline("𝙲𝚑𝚎𝚌𝚔 𝚅𝚙𝚜 𝙸𝚗𝚏𝚘", "info"),
     Button.inline("𝙾𝚝𝚑𝚎𝚛 𝚂𝚎𝚝𝚝𝚒𝚗𝚐", "setting")],
    [Button.inline("𝙼𝚊𝚜𝚞𝚔𝚊𝚗 𝙸𝚙𝚟𝚙𝚜", "regist")]
]

                admin_msg = f"""
◇━━━━━━━━━━━━━━━━━━━━━━━◇ 
🔰 OS  : {namaos.strip().replace('"','')}
🔰 CITY : {city.strip()}
🔰 DOMAIN : {DOMAIN}
🔰 IP VPS : {ipsaya.strip()}
◇━━━━━━━━━━━━━━━━━━━━━━━◇
🔰 Total Account Created:
🔰 SSH OVPN  : {ssh.strip()} account(s)
🔰 XRAY VMESS : {vms.strip()} account(s)
🔰 XRAY VLESS  : {vls.strip()} account(s)
🔰 XRAY TROJAN  : {trj.strip()} account(s)
🔰 XRAY SHADOWSOCKS: {ssk.strip()} account(s)
◇━━━━━━━━━━━━━━━━━━━━━━━◇
🙎‍♂️ USER ID  : {user_id}
💰 SALDO-MU  : Rp.{saldo_aji}
◇━━━━━━━━━━━━━━━━━━━━━━━◇
🙎‍♂️ TOTAL USER BOT : {get_user_count()}
◇━━━━━━━━━━━━━━━━━━━━━━━◇
"""
x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
f'**═════════════════════════**\n'
f'**Selamat Datang di RiswanJabar Store🎉**\n'
f'**Nama:** {first_name} {last_name}\n'
f'**ID Pengguna:** `{user_id}`\n'
f'**Total Reseller:** `{get_user_count()}`\n'
f'**═════════════════════════**\n'
f'**Layanan Anda:**\n'
f'**SSH:** `Tersedia ✅`\n'
f'**VMess:** `Tersedia ✅`\n'
f'**VLess:** `Tersedia ✅`\n'
f'**Trojan:** `Tersedia ✅`\n'
f'**═════════════════════════**\n'
f'**Ditolak:** `Anda Bukan Reseller`🚫\n'
f'**═════════════════════════**\n'
f'**Ingin Bergabung Sebagai Reseller?🤔**\n'
f'**Modal Awal Join:** `Rp 30.000💼`\n'
f'**Khusus Reseller:** `Rp 5.000💸`\n'
f'**Kusus Member:** `Rp 10.000`\n'
f'**Harga Lebih Murah Setelah**\n'
f'**Menjadi Reseller🏷️**\n'
f'**═════════════════════════**\n'
f'**💻PAKET VPS SGDO 🇸🇬**\n'
f'**1️⃣GB RAM, 1 Core:** `IDR 35.000`🇸🇬\n'
f'**2️⃣GB RAM, 1 Core:** `IDR 37.000`🇸🇬\n'
f'**4️⃣GB RAM, 2 Core:** `IDR 55.000`🇸🇬\n'
f'**↪️Gratis Instalasi & Garansi 30 Hari**\n'
f'**↪️Setup Siap Pakai, Skrip Siap Dijual**\n'
f'**↪️Dengan Konfigurasi Lengkap**\n'
f'**═════════════════════════**\n',
buttons=[[
    Button.url("JOIN SEKARANG ?", "https://t.me/JesVpnt")
]]
)
