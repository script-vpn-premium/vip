from datetime import datetime
import subprocess
from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline(" ⚡️SSH OVPN MANAGER⚡️ ", "ssh")],
        [Button.inline(" ⚡️VMESS⚡️ ", "vmess"), Button.inline(" ⚡️VLESS⚡️ ", "vless")],
        [Button.inline(" ⚡️TROJAN⚡️ ", "trojan"), Button.inline(" ⚡️SHDWSK⚡️ ", "shadowsocks")],
        [Button.inline(" ⚡️VPS INFO⚡️ ", "info"), Button.inline(" ⚡️SETTING⚡️ ", "setting")],
        [Button.inline(" 📋LIST SEWA📋 ", "ls-ip")],
        [Button.inline(" ‹✨START✨› ", "start")]
    ]
    
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
    elif val == "true":
        # Mengambil data SSH
        ssh = subprocess.check_output('cat /etc/ssh/.ssh.db | grep "###" | wc -l', shell=True).decode("ascii")
        vms = subprocess.check_output('cat /etc/xray/config.json | grep "###" | wc -l', shell=True).decode("ascii")
        vls = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii")
        trj = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii")
        ssk = subprocess.check_output('cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', shell=True).decode("ascii")
        namaos = subprocess.check_output('cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed "s/=//g" | sed "s/PRETTY_NAME//g"', shell=True).decode("ascii")
        ipsaya = subprocess.check_output('curl -s ipv4.icanhazip.com', shell=True).decode("ascii")
        city = subprocess.check_output('cat /etc/xray/city', shell=True).decode("ascii")
        
        # Membaca tanggal kedaluwarsa dan menghitung sisa hari
        exp_file = "/etc/expiry_date"
        try:
            with open(exp_file, "r") as f:
                exp_date_str = f.read().strip()
            exp_date = datetime.strptime(exp_date_str, "%Y-%m-%d")  # Format YYYY-MM-DD
            today = datetime.today()
            remaining_days = (exp_date - today).days
        except Exception as e:
            remaining_days = "Tidak diketahui"
        
        # Mendapatkan informasi pengguna
        user_id = sender.id
        username = sender.username
        
        msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
              	**⚡️ ADMIN PANEL MENU ⚡️**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
**»🔰OS :** `{namaos.strip().replace('"','')}`
**»🔰DOMAIN :** `{DOMAIN}`
**»🔰IP VPS :** `{ipsaya.strip()}`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**»🔰Total Account Created:** 
**»🔰SSH OVPN:** `{ssh.strip()}` __account__
**»🔰XRAY VMESS:** `{vms.strip()}` __account__
**»🔰XRAY VLESS:** `{vls.strip()}` __account__
**»🔰XRAY TROJAN:** `{trj.strip()}` __account__
**»🔰XRAY SHDWSK:** `{ssk.strip()}` __account__
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
**»🔰User ID:** `{user_id}`
**»🔰User: @{username}**
**»🔰Masa Aktif Script:** `{remaining_days}` __hari__
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
"""
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)