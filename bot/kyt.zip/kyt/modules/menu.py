from kyt import *
from datetime import datetime, timedelta
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("𝗦𝗦𝗛 𝗪𝗦", "ssh"), Button.inline("𝗩𝗠𝗘𝗦𝗦", "vmess")],
        [Button.inline("𝗧𝗥𝗢𝗝𝗔𝗡", "trojan"), Button.inline("𝗩𝗣𝗦 𝗜𝗡𝗙𝗢", "info")],
        [Button.inline("𝗦𝗘𝗧𝗜𝗡𝗚", "setting"), Button.inline("𝗟𝗜𝗦𝗧 𝗦𝗘𝗪𝗔", "ls-ip")],
        [Button.url("𝗚𝗥𝗨𝗣 𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠", "https://t.me/jesvpntun")]  # Add URL button here
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply(f"**Akses Ditolak: Anda tidak terdaftar  Untuk daftar beli VPS dan auto script owner** @JesVpnt")
    elif val == "true":
        # Mengambil jumlah akun dari database
        ssh = subprocess.check_output("cat /etc/ssh/.ssh.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        vms = subprocess.check_output("cat /etc/xray/config.json | grep '###' | wc -l", shell=True).decode("ascii").strip()
        vls = subprocess.check_output("cat /etc/vless/.vless.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        trj = subprocess.check_output("cat /etc/trojan/.trojan.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        ssk = subprocess.check_output("cat /etc/shadowsocks/.shadowsocks.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        
        # Mengambil informasi sistem
        namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'", shell=True).decode("ascii").strip().replace('"','')
        ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
        city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii").strip()

        # Mengambil informasi pengguna
        user_id = sender.id
        username = sender.username

        # Misalnya, tanggal VPS dibuat ada di file /etc/vps_creation_date.txt
        try:
            with open("/etc/vps_creation_date.txt", "r") as file:
                creation_date_str = file.read().strip()  # Format tanggal misalnya "2025-03-01"
            creation_date = datetime.strptime(creation_date_str, "%Y-%m-%d")
        except Exception as e:
            creation_date = datetime.now()  # Default to the current date if no creation date is found
        
        # Set the expiry period (e.g., 30 days)
        expiry_period = timedelta(days=30)
        expiry_date = creation_date + expiry_period
        
        # Menghitung sisa waktu aktif
        remaining_days = (expiry_date - datetime.now()).days
        if remaining_days < 0:
            remaining_days = 0  # If expired, set remaining days to 0

        # Pesan menu dengan semua informasi
        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
   **≡  P G E TUNNEL  MENU BOT  ≡**
**━━━━━━━━━━━━━━━━━━━━━━━**
**✨ VPS DETAILS**
**• OS :** `{namaos}`
**• Location :** `{city}`
**• Host :** `{DOMAIN}`
**• IP VPS :** `{ipsaya}`
**• Expiry :** `{remaining_days} Days`
**━━━━━━━━━━━━━━━━━━━━━━━**
**🔒 ACCOUNT STATUS**
**• SSH :** `{ssh} Account`
**• VMESS :** `{vms} Account`
**• TROJAN :** `{trj} Account`
**━━━━━━━━━━━━━━━━━━━━━━━**
**🧑‍💻 USER PROFILE**
**• User ID :** `{user_id}`
**• Username :** @{username}
**━━━━━━━━━━━━━━━━━━━**
"""
        # Kirim gambar dan pesan sekaligus
        await event.respond(
            message=msg, 
            buttons=inline
        )