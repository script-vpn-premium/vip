from kyt import *
from datetime import datetime
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline(" ⚡️SSH OVPN MANAGER⚡️ ", "ssh")],
        [Button.inline(" ⚡️VMESS⚡️ ", "vmess"), Button.inline(" ⚡️VLESS⚡️ ", "vless")],
        [Button.inline(" ⚡️TROJAN⚡️ ", "trojan"), Button.inline(" ⚡️SHDWSK⚡️ ", "shadowsocks")],
        [Button.inline(" ⚡️VPS INFO⚡️ ", "info"), Button.inline(" ⚡️SETTING⚡️ ", "setting")],
        [Button.inline(" 📋LIST SEWA📋 ", "ls-ip")],  
        [Button.inline(" ‹✨START✨› ", "start")]
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
        return

    # Fungsi untuk menghitung jumlah akun
    def get_count(file_path):
        try:
            count = subprocess.check_output(f"grep -c '###' {file_path}", shell=True).decode("utf-8").strip()
            return count if count else "0"
        except:
            return "0"

    ssh = get_count("/etc/ssh/.ssh.db")
    vms = get_count("/etc/xray/config.json")
    vls = get_count("/etc/vless/.vless.db")
    trj = get_count("/etc/trojan/.trojan.db")
    ssk = get_count("/etc/shadowsocks/.shadowsocks.db")

    # Mengambil informasi sistem
    try:
        namaos = subprocess.check_output("grep -w PRETTY_NAME /etc/os-release | cut -d '=' -f2 | tr -d '\"'", shell=True).decode("utf-8").strip()
    except:
        namaos = "Tidak diketahui"

    try:
        ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("utf-8").strip()
    except:
        ipsaya = "Tidak ditemukan"

    try:
        with open("/etc/xray/city", "r") as f:
            city = f.read().strip()
    except:
        city = "Tidak diketahui"

    # Mengambil tanggal kadaluarsa script dan menghitung hitungan mundur
    try:
        with open("/etc/expiry-date", "r") as f:
            expiry_date_str = f.read().strip()

        # Pastikan format tanggal benar
        expiry_date = datetime.strptime(expiry_date_str, "%Y-%m-%d")
        today = datetime.today()
        
        # Menghitung selisih hari
        remaining_days = (expiry_date - today).days

        # Menampilkan hitungan mundur dengan benar
        if remaining_days > 0:
            expiry_msg = f"**»🔰Script Expiry:** `{expiry_date_str}` (**{remaining_days} hari lagi**)"
        elif remaining_days == 0:
            expiry_msg = f"**»🔰Script Expiry:** `{expiry_date_str}` (**HARI INI KADALUARSA!**)"
        else:
            expiry_msg = f"**»🔰Script Expiry:** `TELAH KADALUWARSA ({abs(remaining_days)} hari lalu)`"
    except:
        expiry_msg = "**»🔰Script Expiry:** `Tidak diketahui`"

    # Mengambil informasi pengguna
    user_id = sender.id
    username = sender.username if sender.username else "Tidak ada username"

    # Pesan menu dengan semua informasi
    msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
		      	**⚡️ ADMIN PANEL MENU ⚡️**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
**»🔰OS :** `{namaos}`
**»🔰DOMAIN :** `{DOMAIN}`
**»🔰IP VPS :** `{ipsaya}`
**»🔰CITY :** `{city}`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**»🔰Total Akun Yang Dibuat:** 
**»🔰SSH OVPN:** `{ssh}` __Account__
**»🔰XRAY VMESS:** `{vms}` __Account__
**»🔰XRAY VLESS:** `{vls}` __Account__
**»🔰XRAY TROJAN:** `{trj}` __Account__
**»🔰XRAY SHDWSK:** `{ssk}` __Account__
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
**»🔰User ID:** `{user_id}`
**»🔰User: @{username}**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇** 
"""

    # Mengirim pesan ke pengguna
    try:
        await event.edit(msg, buttons=inline)
    except:
        await event.reply(msg, buttons=inline)