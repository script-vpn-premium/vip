from kyt import *
from datetime import datetime
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [

    
    [Button.inline(" 🖥️SSH🖥️ ", "ssh"), Button.inline(" 🌍VMESS🌍 ", "vmess")],
    [Button.inline(" 🔒TROJAN🔒 ", "trojan"), Button.inline(" 📊VPS INFO📊 ", "info")],
    [Button.inline(" ⚙️SETTING⚙️ ", "setting"), Button.inline(" 📋LIST SEWA📋 ", "ls-ip")],
    [Button.inline(" 🚀START🚀 ", "start")]
]

    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
    elif val == "true":
        # Mengambil jumlah akun dari database
        ssh = subprocess.check_output("cat /etc/ssh/.ssh.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        vms = subprocess.check_output("cat /etc/xray/config.json | grep '###' | wc -l", shell=True).decode("ascii").strip()
        vls = subprocess.check_output("cat /etc/vless/.vless.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        trj = subprocess.check_output("cat /etc/trojan/.trojan.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        ssk = subprocess.check_output("cat /etc/shadowsocks/.shadowsocks.db | grep '###' | wc -l", shell=True).decode("ascii").strip()
        
        # Mengambil informasi sistem
        namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'", shell=True).decode("ascii").strip().replace('"','')
        ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
        city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii").strip()

        # Mengambil tanggal kedaluwarsa script
        try:
            with open("/etc/expiry-date", "r") as f:
                expiry_date_str = f.read().strip()
            expiry_date = datetime.strptime(expiry_date_str, "%Y-%m-%d")
            today = datetime.today()
            remaining_days = (expiry_date - today).days
            expiry_msg = f"**»🔰Script Expiry:** `{expiry_date_str}` (**{remaining_days}** hari lagi)"
        except:
            expiry_msg = "**»🔰Script Expiry:** `Tidak diketahui`"

        # Mengambil informasi pengguna
        user_id = sender.id
        username = sender.username

        # Pesan menu dengan semua informasi
        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
    **≡       MENU BOT SIMPLE        ≡**
**━━━━━━━━━━━━━━━━━━━━━━━**
**»Os :** `{namaos}`
**»Kota :** `{city}`
**»host :** `{DOMAIN}`
**»Ip vps :** `{ipsaya}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**»SSH :** `{ssh} Account`
**»VMESS:** `{vms} Account`
**»TROJAN:** `{trj} Account`
**━━━━━━━━━━━━━━━━━━━━━━━** 
**»Owner** @JesVpnt
"""
        # Kirim gambar dan pesan sekaligus
        await event.respond(

            message=msg, 
            buttons=inline
        )

