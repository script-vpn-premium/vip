from kyt import *

#detail
@bot.on(events.CallbackQuery(data=b'd-trojan'))
async def l_trojan(event):
	async def l_trojan_(event):
		cmd = 'cat /etc/xray/config.json | grep "^#!" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Trojan Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as exp:
			await event.respond(" **Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'cat /var/www/html/trojan-{exp}.txt'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		if z:
			await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Trojan Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""",buttons=[[Button.inline("‹ Back ›","trojan")]])
		else:
			await event.respond("**Filed**: User tidak ditemukan", buttons=[[Button.inline("‹ Back ›","trojan")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await l_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#LOCK trojan
@bot.on(events.CallbackQuery(data=b'lock-trojan'))
async def lock_trojan(event):
	async def lock_trojan_(event):
		cmd = 'cat /etc/xray/config.json | grep "^#!" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Trojan Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as exp:
			await event.respond(" **Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "{exp}" | lock-tr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except subprocess.CalledProcessError:  # Menangani kesalahan jika user tidak ada
			await event.respond(f" **Successfully**", buttons=[[Button.inline("‹ Back ›","trojan")]])
		else:
			await event.respond(f" **Successfully Lock**", buttons=[[Button.inline("‹ Back ›","trojan")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await lock_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
#UNLOCK trojan
@bot.on(events.CallbackQuery(data=b'unlock-trojan'))
async def unlock_trojan(event):
	async def unlock_trojan_(event):
		cmd = 'cat /etc/xray/.lock.db | grep "^#!" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Trojan Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as exp:
			await event.respond(" **Username:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "{exp}" | unlock-tr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except subprocess.CalledProcessError:  # Menangani kesalahan jika user tidak ada
			await event.respond(f" **Successfully**", buttons=[[Button.inline("‹ Back ›","trojan")]])
		else:
			await event.respond(f" **Successfully Unlock**", buttons=[[Button.inline("‹ Back ›","trojan")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await unlock_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)


@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
	async def create_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond(' **Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as limit_ip:
			await event.respond("🌐 **Limit IP:**")
			limit_ip = limit_ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limit_ip = (await limit_ip).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("📊 **Quota:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("⏳ **Masaaktif:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		async with bot.conversation(chat) as bug:
			await event.respond("🐞 **PILIH BUG OTOMATIS**",buttons=[
[Button.inline("🎥 XL VIDIO", "quiz.vidio.com"), 
     Button.inline("📚 TESL IPED", "www.uii.ac.id")],
    [Button.inline("📱AXIS EDU", "104.17.3.81"), 
     Button.inline("🌍 TESL RGU", "172.67.22.129")],
    [Button.inline("🎮 ISAT FUN", "104.17.241.25"), 
     Button.inline("🎮 ISAT GAME", "104.18.62.229")],
    [Button.inline("🎥 AXIS VIDIO", "104.22.5.240"), 
     Button.inline("📚 XL EDU", "104.17.3.81")],
    [Button.inline("🆗 NO BUG", "bugkamu.com")]
])
			bug = bug.wait_event(events.CallbackQuery)
			bug = (await bug).data.decode("ascii")
		cmd = f'printf "%s\n" "{user}" "{limit_ip}" "{pw}" "{exp}" "{bug}" | addtr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			inline=[[Button.inline("‹ Back ›","trojan")]]
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("trojan://(.*)",a)]
			print(b)
			uuid = re.search("trojan://(.*?)@",b[0]).group(1)
			msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
		**⚡️ Xray/Trojan Account ⚡️**
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Remarks     :** `{user}`
**» Limit IP    :** `{limit_ip}`
**» Host Server :** `{DOMAIN}`
**» User Quota  :** `{pw} GB`
**» Port DNS    :** `443, 53`
**» port TLS    :** `222-1000`
**» User ID     :** `{uuid}`
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Link WS    :** 
```{b[0].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Link Ntls   :** 
```{b[1].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Link GRPC  :** 
```{b[2].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Format OpenClash :** 
https://{DOMAIN}:81/trojan-{user}.txt
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**Expired Until:** `{later}`
**» 🤖@JesVpnt**
"""
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'auto-trojan'))
async def create_trojan(event):
	async def create_trojan_(event):
		async with bot.conversation(chat) as limit_ip:
			await event.respond("🌐 **Limit IP:**")
			limit_ip = limit_ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			limit_ip = (await limit_ip).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("📊 **Quota:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("⏳ **Masaaktif:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		async with bot.conversation(chat) as bug:
			await event.respond("🐞 **PILIH BUG OTOMATIS**",buttons=[
[Button.inline("🎥 XL VIDIO", "quiz.vidio.com"), 
     Button.inline("📚 TESL IPED", "www.uii.ac.id")],
    [Button.inline("📱AXIS EDU", "104.17.3.81"), 
     Button.inline("🌍 TESL RGU", "172.67.22.129")],
    [Button.inline("🎮 ISAT FUN", "104.17.241.25"), 
     Button.inline("🎮 ISAT GAME", "104.18.62.229")],
    [Button.inline("🎥 AXIS VIDIO", "104.22.5.240"), 
     Button.inline("📚 XL EDU", "104.17.3.81")],
    [Button.inline("🆗 NO BUG", "bugkamu.com")]
])
			bug = bug.wait_event(events.CallbackQuery)
			bug = (await bug).data.decode("ascii")
		user = "TrojanPrem"+str(random.randint(100,1000))
		cmd = f'printf "%s\n" "{user}" "{limit_ip}" "{pw}" "{exp}" "{bug}" | addtr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			inline=[[Button.inline("‹ Back ›","trojan")]]
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("trojan://(.*)",a)]
			print(b)
			uuid = re.search("trojan://(.*?)@",b[0]).group(1)
			msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
		**⚡️ Xray/Trojan Account ⚡️**
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Remarks     :** `{user}`
**» Limit IP    :** `{limit_ip}`
**» Host Server :** `{DOMAIN}`
**» User Quota  :** `{pw} GB`
**» Port DNS    :** `443, 53`
**» port TLS    :** `222-1000`
**» User ID     :** `{uuid}`
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Link WS    :** 
```{b[0].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Link Ntls   :** 
```{b[1].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Link GRPC  :** 
```{b[2].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Format OpenClash :** 
https://{DOMAIN}:81/trojan-{user}.txt
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**Expired Until:** `{later}`
**» 🤖@JesVpnt**
"""
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'cek-trojan'))
async def cek_trojan(event):
	async def cek_trojan_(event):
		cmd = 'bot-cek-tr'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Trojan Logged🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```					  
{z}
```
**Shows Logged In Users Trojan**
**» 🤖@JesVpnt**
""",buttons=[[Button.inline("‹ Back ›","trojan")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
	async def trial_trojan_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Menit ","10"),
Button.inline(" 15 Menit ","15")],
[Button.inline(" 30 Menit ","30"),
Button.inline(" 60 Menit ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'printf "%s\n" "{exp}" | trialtr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			inline=[[Button.inline("‹ Back ›","trojan")]]
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("trojan://(.*)",a)]
			print(b)
			remarks = re.search("#(.*)",b[0]).group(1)
			uuid = re.search("trojan://(.*?)@",b[0]).group(1)
			msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
		**⚡️ Xray/Trojan Account ⚡️**
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Remarks     :** `{remarks}`
**» Host Server :** `{DOMAIN}`
**» User Quota  :** `Unlimited`
**» Port DNS    :** `443, 53`
**» port TLS    :** `222-1000`
**» Path Trojan :** `(/multi path)/trojan-ws`
**» User ID     :** `{uuid}`
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Link WS    :** 
```{b[0].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Link GRPC  :** 
```{b[2].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Format OpenClash :** 
https://{DOMAIN}:81/trojan-{remarks}.txt
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{exp} Minutes`
**» 🤖@JesVpnt**
"""
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
	async def delete_trojan_(event):
		cmd = 'cat /etc/xray/config.json | grep "^#!" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Trojan Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond(' **Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | deltr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except subprocess.CalledProcessError:  # Menangani kesalahan jika user tidak ada
			await event.respond(f" **Successfully**", buttons=[[Button.inline("‹ Back ›","trojan")]])
		else:
			await event.respond(f" **Successfully Delet**", buttons=[[Button.inline("‹ Back ›","trojan")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'bot-member-trojan'))
async def bot_member_trojan(event):
	async def bot_member_trojan_(event):
		cmd = 'cat /etc/xray/config.json | grep "^#!" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Trojan Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
**Menampilkan Member Trojan**
**» 🤖@JesVpnt**
""",buttons=[[Button.inline("‹ Back ›","trojan")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await bot_member_trojan_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-tr'))
async def renew_tr(event):
	async def renew_tr_(event):
		cmd = 'cat /etc/xray/config.json | grep "^#!" | cut -d " " -f 2-3 | sort | uniq | nl'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
	** ⟨🔸 Trojan Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━━◇**
```
{z}
```
""")
		async with bot.conversation(chat) as user:
			await event.respond(' **Username Renew:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond('⏳ **Ubah Masaaktif:**')
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "{user}" "{exp}" | renewtr'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Successfully**",buttons=[[Button.inline("‹ Back ›","trojan")]])
		else:
			await event.respond(f"**Successfully Renew** `{user}`",buttons=[[Button.inline("‹ Back ›","trojan")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_tr_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)


@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
	async def trojan_(event):
		inline = [
[Button.inline("⚡️Auto Trojan⚡️","auto-trojan")],
[Button.inline(" ☣️Trial Trojan ","trial-trojan"),
Button.inline(" ➕Create Trojan ","create-trojan")],
[Button.inline(" 👤Member Trojan ","bot-member-trojan"),
Button.inline(" ♻️Renew Trojan ","renew-tr")],
[Button.inline(" ✅Check Trojan ","cek-trojan"),
Button.inline(" ❌Delete Trojan ","delete-trojan")],
[Button.inline(" 🔒Lock Trojan ","lock-trojam"),
Button.inline(" 🔐Unlock Trojan ","unlock-trojan")],
[Button.inline(" 📝Detail Trojan ","d-trojan")],
[Button.inline("‹ Back ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess. check_output(tr, shell=True).decode("ascii")
		username = sender.username
		user_id = sender.id
		msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
	        		**⚡️ TROJAN MANAGER ⚡️**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**»🔰Service:** `TROJAN`
**»🔰Jumlah TROJAN :** `{trj.strip()}` __account__
**»🔰Hostname/IP:** `{DOMAIN}`
**»🔰ISP:** `{z["isp"]}`
**»🔰Country:** `{z["country"]}`
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**»🆔User ID:** `{user_id}`
**»👤Username:@{username}**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)
